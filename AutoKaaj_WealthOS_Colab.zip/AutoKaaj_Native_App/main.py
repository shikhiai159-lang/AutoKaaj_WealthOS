import os
import json
import threading
import subprocess
from pathlib import Path
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.uix.text_input import TextInput
from kivy.uix.button import Button
from kivy.uix.scrollview import ScrollView
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.core.window import Window
from kivy.utils import get_color_from_hex

# --- CYBERPUNK THEME PALETTE ---
BKG_COLOR = get_color_from_hex("#0a0a0f")
ACCENT_COLOR = get_color_from_hex("#00f2ff")
TEXT_COLOR = get_color_from_hex("#e0e0e0")
GOLD_COLOR = get_color_from_hex("#ffd700")

class CommandCenter(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.layout = BoxLayout(orientation='vertical', padding=20, spacing=10)
        
        # Header
        self.header = Label(
            text="[b]AUTOKAAJ COMMAND CENTER[/b]", 
            markup=True, 
            font_size='24sp', 
            color=ACCENT_COLOR,
            size_hint_y=None, height=50
        )
        self.layout.add_widget(self.header)

        # Console Output
        self.console = Label(
            text="System Ready... Waiting for input...", 
            halign='left', 
            valign='top', 
            text_size=(Window.width - 40, None),
            color=TEXT_COLOR,
            size_hint_y=5
        )
        self.scroll = ScrollView()
        self.scroll.add_widget(self.console)
        self.layout.add_widget(self.scroll)

        # Input Area
        self.input_box = TextInput(
            hint_text="Enter Synthesis Command...", 
            multiline=False, 
            size_hint_y=None, height=50,
            background_color=(0.1, 0.1, 0.1, 1),
            foreground_color=ACCENT_COLOR
        )
        self.layout.add_widget(self.input_box)

        # Action Button
        self.btn_exec = Button(
            text="EXECUTE SYNTHESIS", 
            background_color=ACCENT_COLOR, 
            color=(0,0,0,1),
            size_hint_y=None, height=60
        )
        self.btn_exec.bind(on_press=self.execute_command)
        self.layout.add_widget(self.btn_exec)

        self.add_widget(self.layout)

    def execute_command(self, instance):
        cmd = self.input_box.text
        self.console.text += f"\n\n> {cmd}"
        # bridge to wealth_engine logic
        self.process_ai_logic(cmd)
        self.input_box.text = ""

    def process_ai_logic(self, cmd):
        # In a real app, this calls the WealthEngine.py internal methods
        self.console.text += "\n[*] Engaging Mega-Synthesis Engine..."
        # Simulate AI delay
        threading.Thread(target=self.simulate_ai_response).start()

    def simulate_ai_response(self):
        time.sleep(2)
        self.console.text += "\n[✓] Software materializing... HTML/CSS/JS generated.\n[!] Localhost:8000 Active."

class PremiumScreen(Screen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        layout = BoxLayout(orientation='vertical', padding=30, spacing=20)
        
        layout.add_widget(Label(text="💎 PREMIUM UNLOCK 💎", font_size='30sp', color=GOLD_COLOR))
        
        # Pricing Tiers
        layout.add_widget(Label(text="Daily Pass: ₹49 (24h Access)", color=TEXT_COLOR))
        layout.add_widget(Label(text="Business Access: ₹499 (Monthly)", color=TEXT_COLOR))
        
        # UPI Section
        layout.add_widget(Label(text="UPI ID: 7557072451@slc\n(Scan QR in 1000046902.jpg)", halign='center', color=ACCENT_COLOR))
        
        self.tx_input = TextInput(hint_text="Enter Transaction ID (UTR)", multiline=False, size_hint_y=None, height=50)
        layout.add_widget(self.tx_input)
        
        btn_verify = Button(text="VERIFY PAYMENT", background_color=GOLD_COLOR, color=(0,0,0,1))
        btn_verify.bind(on_press=self.verify_payment)
        layout.add_widget(btn_verify)
        
        self.add_widget(layout)

    def verify_payment(self, instance):
        # Validation logic
        self.manager.current = 'main'

class AutoKaajApp(App):
    def build(self):
        Window.clearcolor = BKG_COLOR
        sm = ScreenManager()
        sm.add_widget(CommandCenter(name='main'))
        sm.add_widget(PremiumScreen(name='premium'))
        return sm

if __name__ == "__main__":
    import time
    AutoKaajApp().run()
